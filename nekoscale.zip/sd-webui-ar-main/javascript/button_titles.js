// Do not put custom titles here. This file is overwritten each time the WebUI is started.
ar_button_titles = {}